package com.example.healthbuddypro.ShortTermMatching;

public interface OnPostSubmitListener {
    void onPostSubmitted(String title, String content);
}
