package com.example.healthbuddypro;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_detail);

        // 전달된 프로필 데이터 받아서 UI에 표시
    }
}
