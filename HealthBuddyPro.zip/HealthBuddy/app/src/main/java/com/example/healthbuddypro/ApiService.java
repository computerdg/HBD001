package com.example.healthbuddypro;

import com.example.healthbuddypro.Login.LoginRequest;
import com.example.healthbuddypro.Login.LoginResponse;
import com.example.healthbuddypro.Matching.ProfileResponse;
import com.example.healthbuddypro.Matching.UserProfile;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {

    // 로그인
    @POST("/api/login")
    Call<LoginResponse> login(@Body LoginRequest loginRequest);

    // 회원가입
    @POST("/api/join") // 실제 서버의 회원가입 엔드포인트로 수정
    Call<com.example.healthbuddypro.Signup.SignUpResponse> signup(@Body com.example.healthbuddypro.Signup.SignUpRequest signUpRequest);

    @GET("/api/match/profile")
    Call<ProfileResponse> getProfiles();

    @GET("/api/match/profile")
    Call<List<UserProfile>> getUserProfiles();


}
